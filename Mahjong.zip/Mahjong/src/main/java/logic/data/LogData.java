package logic.data;

public class LogData {
}
