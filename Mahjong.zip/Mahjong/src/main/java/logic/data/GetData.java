package logic.data;

public class GetData {
}
