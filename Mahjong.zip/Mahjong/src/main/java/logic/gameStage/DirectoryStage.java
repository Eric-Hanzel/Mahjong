package logic.gameStage;

import logic.data.GetData;
import logic.players.Player;

import java.util.ArrayList;
import java.util.EventListener;

public class DirectoryStage {
    private ArrayList<Player> playerArrayList;
    private PreparatoryStage gameMatch;
    private String gameStage;
    private EventListener eventListener;
    private GetData getData;

    public PreparatoryStage creatMatch(){
        return null;

    }

    public PreparatoryStage joinMatch(){
        return null;

    }

    public void exitGame(){
    }
}
