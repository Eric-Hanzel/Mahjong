package logic.gameStage;

public class EndStage {
}
