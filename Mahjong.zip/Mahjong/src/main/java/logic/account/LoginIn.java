package logic.account;

public class LoginIn {
}
