package logic.rules;

public class ScoringRule {
}
