package logic.gameManagement;

public class Game {
}
